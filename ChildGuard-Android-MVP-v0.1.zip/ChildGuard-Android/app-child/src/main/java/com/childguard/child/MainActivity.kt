package com.childguard.child

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.random.Random

class MainActivity : ComponentActivity() { override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { ChildApp() } } }
@Composable fun ChildApp() {
 var paired by remember { mutableStateOf(false) }
 val code = remember { (100000..999999).random() }
 MaterialTheme { Surface(Modifier.fillMaxSize()) { Column(Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
  Text("ChildGuard",style=MaterialTheme.typography.headlineLarge)
  if (!paired) { Text("هذا الجهاز سيتم ربطه بحساب ولي الأمر لإدارة إعدادات الرقابة الأبوية.")
   Card { Column(Modifier.padding(20.dp)) { Text("رمز الربط",style=MaterialTheme.typography.titleLarge); Text(code.toString(),style=MaterialTheme.typography.displaySmall); Text("أدخل هذا الرمز في تطبيق الوالد.") } }
   Text("ملاحظة: رمز الربط في هذه النسخة هو واجهة إعداد؛ الربط الحقيقي يحتاج نشر Backend وتكوين عنوان API.")
   Button(onClick={paired=true},modifier=Modifier.fillMaxWidth()){Text("محاكاة إتمام الربط")}
  } else { Text("🟢 تم ربط الجهاز بنجاح",style=MaterialTheme.typography.titleLarge); Text("مركز الصلاحيات"); Text("📍 الموقع — يحتاج موافقة النظام"); Text("🔔 الإشعارات — يحتاج موافقة النظام"); Text("📱 إحصاءات الاستخدام — يحتاج تفعيل النظام"); Text("🖥️ مشاركة الشاشة — تبدأ فقط بموافقة واضحة عبر MediaProjection"); Button(onClick={},modifier=Modifier.fillMaxWidth()){Text("🆘 طلب مساعدة")} }
 } } }
}
