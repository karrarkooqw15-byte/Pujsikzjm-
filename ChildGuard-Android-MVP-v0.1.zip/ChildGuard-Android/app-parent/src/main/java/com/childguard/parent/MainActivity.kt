package com.childguard.parent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { ParentApp() } }
}

@Composable fun ParentApp() {
 var code by remember { mutableStateOf("") }
 MaterialTheme { Surface(Modifier.fillMaxSize()) { LazyColumn(Modifier.padding(20.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
  item { Text("ChildGuard Parent", style=MaterialTheme.typography.headlineMedium) }
  item { Text("لوحة ولي الأمر", style=MaterialTheme.typography.titleLarge) }
  item { Card { Column(Modifier.padding(16.dp)) { Text("👶 جهاز الطفل"); Text("🔴 غير متصل"); Spacer(Modifier.height(8.dp)); Text("🔋 البطارية: —"); Text("📍 آخر موقع: —") } } }
  item { OutlinedTextField(value=code,onValueChange={code=it.filter(Char::isDigit).take(6)},label={Text("رمز الربط")},singleLine=true,modifier=Modifier.fillMaxWidth()) }
  item { Button(onClick={},modifier=Modifier.fillMaxWidth()) { Text("ربط جهاز الطفل") } }
  item { Card { Column(Modifier.padding(16.dp)) { Text("📊 وقت الشاشة",style=MaterialTheme.typography.titleMedium); Text("اليوم: —"); Text("هذا الأسبوع: —") } } }
  item { Card { Column(Modifier.padding(16.dp)) { Text("🔔 التنبيهات",style=MaterialTheme.typography.titleMedium); Text("لا توجد تنبيهات جديدة") } } }
  item { Card { Column(Modifier.padding(16.dp)) { Text("⚙️ الإعدادات",style=MaterialTheme.typography.titleMedium); Text("إدارة الحساب • فصل الجهاز • الخصوصية") } } }
 } } }
}
