#!/usr/bin/env bash
set -e
if command -v gradle >/dev/null; then gradle :app-parent:assembleDebug :app-child:assembleDebug; else echo 'Install Gradle 8.7+ or run GitHub Actions.'; exit 1; fi
