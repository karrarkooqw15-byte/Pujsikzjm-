import { Redis } from '@upstash/redis';
const redis = process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN ? new Redis({url:process.env.KV_REST_API_URL,token:process.env.KV_REST_API_TOKEN}) : null;
const key = 'childguard:pairing:';
function code(){return String(Math.floor(100000+Math.random()*900000));}
export default async function handler(req,res){
 res.setHeader('Access-Control-Allow-Origin','*'); res.setHeader('Access-Control-Allow-Headers','content-type');
 if(req.method==='OPTIONS') return res.status(204).end();
 if(req.method==='POST'){
  const {action,deviceId,code:input}=req.body||{};
  if(action==='create'){
   const c=code(); const session={deviceId,createdAt:Date.now()};
   if(redis) await redis.set(key+c,session,{ex:600});
   return res.status(200).json({code:c,expiresIn:600});
  }
  if(action==='claim'){
   if(!redis) return res.status(503).json({error:'Backend storage is not configured'});
   const session=await redis.get(key+input); if(!session) return res.status(400).json({error:'Invalid or expired code'});
   await redis.del(key+input); return res.status(200).json({paired:true,childDeviceId:session.deviceId});
  }
 }
 return res.status(405).json({error:'Method not allowed'});
}
