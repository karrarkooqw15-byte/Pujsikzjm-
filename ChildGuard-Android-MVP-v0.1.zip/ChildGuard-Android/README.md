# ChildGuard

مشروع Android ثنائي: ChildGuard Parent وChildGuard Child، مع Backend API قابل للنشر.

## مهم
هذه حزمة مصدر + GitHub Actions وليست APK جاهزًا. بناء APK يحتاج Android SDK/Gradle أو GitHub Actions.

## البناء
```bash
./gradlew :app-parent:assembleDebug :app-child:assembleDebug
```

الناتج:
- `app-parent/build/outputs/apk/debug/app-parent-debug.apk`
- `app-child/build/outputs/apk/debug/app-child-debug.apk`

## Backend
المجلد `backend` يحتوي API أولي لنظام pairing. لتخزين دائم في Vercel استخدم Redis/قاعدة بيانات مُدارة واضبط متغيرات البيئة بدل الذاكرة المؤقتة.
